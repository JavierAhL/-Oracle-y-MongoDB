-- Eliminar los objetos existentes (si existen)
DROP TYPE OBJ_Cliente_type;
DROP TYPE OBJ_Producto_type;
DROP TYPE OBJ_Det_Pedido_type;
DROP TYPE OBJ_Pedido_type;
DROP TYPE OBJ_Orden_Entrega_type;
DROP TYPE OBJ_Orden_Recogida_type;
DROP TYPE OBJ_Cliente_tabtype;
DROP TYPE OBJ_Producto_tabtype;
DROP TYPE OBJ_Det_Pedido_tabtype;
DROP TYPE OBJ_Pedido_tabtype;
DROP TYPE OBJ_Orden_Entrega_tabtype;
DROP TYPE OBJ_Orden_Recogida_tabtype;
DROP TABLE Cliente;
DROP TABLE Producto;
DROP TABLE Det_Pedido;
DROP TABLE Pedido;
DROP TABLE Orden_Entrega;
DROP TABLE Orden_Recogida;

-- Crear el tipo de objeto Cliente
CREATE TYPE OBJ_Cliente_type AS OBJECT (
  cif NUMBER,
  nombre VARCHAR2(100),
  direccion VARCHAR2(200),
  telefono VARCHAR2(20),
  numero_cuenta NUMBER,
  MEMBER FUNCTION obtenerNombre RETURN VARCHAR2
);
/

-- Crear el tipo de objeto Producto
CREATE TYPE OBJ_Producto_type AS OBJECT (
  id_producto NUMBER,   
  nombre VARCHAR2(100),
  descripcion VARCHAR2(200),
  disponibilidad VARCHAR2(50),
  MEMBER FUNCTION obtenerDescripcion RETURN VARCHAR2
);
/

-- Crear el tipo de objeto Det.Pedido
CREATE TYPE OBJ_Det_Pedido_type AS OBJECT (
  id_detalle NUMBER,
  id_pedido NUMBER,
  id_producto NUMBER,
  MEMBER FUNCTION obtenerPedido RETURN NUMBER,
  MEMBER FUNCTION obtenerProducto RETURN NUMBER
);
/

-- Crear el tipo de objeto Pedido
CREATE TYPE OBJ_Pedido_type AS OBJECT (
  id_pedido NUMBER,
  fecha DATE,
  estado VARCHAR2(50),
  factura VARCHAR2(100),
  cif NUMBER,
  MEMBER FUNCTION obtenerCliente RETURN NUMBER
);
/

-- Crear el tipo de objeto Orden Entrega
CREATE TYPE OBJ_Orden_Entrega_type AS OBJECT (
  id_entrega NUMBER,
  fecha_entrega DATE,
  id_pedido NUMBER,
  direcion_entrega VARCHAR2(100),
  transportista VARCHAR(50),
  MEMBER FUNCTION obtenerPedido RETURN NUMBER
);
/

-- Crear el tipo de objeto Orden Recogida
CREATE TYPE OBJ_Orden_Recogida_type AS OBJECT (
  id_recogida NUMBER,
  fecha_recogida DATE,
  id_pedido NUMBER,
  transportista VARCHAR(50),
  MEMBER FUNCTION obtenerPedido RETURN NUMBER
);
/

-- Crear el tipo de tabla Cliente
CREATE TYPE OBJ_Cliente_tabtype AS TABLE OF OBJ_Cliente_type;
/

-- Crear el tipo de tabla Producto
CREATE TYPE OBJ_Producto_tabtype AS TABLE OF OBJ_Producto_type;
/

-- Crear el tipo de tabla Det.Pedido
CREATE TYPE OBJ_Det_Pedido_tabtype AS TABLE OF OBJ_Det_Pedido_type;
/

-- Crear el tipo de tabla Pedido
CREATE TYPE OBJ_Pedido_tabtype AS TABLE OF OBJ_Pedido_type;
/

-- Crear el tipo de tabla Orden Entrega
CREATE TYPE OBJ_Orden_Entrega_tabtype AS TABLE OF OBJ_Orden_Entrega_type;
/

-- Crear el tipo de tabla Orden Recogida
CREATE TYPE OBJ_Orden_Recogida_tabtype AS TABLE OF OBJ_Orden_Recogida_type;
/

-- Crear la tabla Cliente
CREATE TABLE Cliente OF OBJ_Cliente_type (
  cif PRIMARY KEY
);

-- Crear la tabla Producto
CREATE TABLE Producto OF OBJ_Producto_type (
  id_producto PRIMARY KEY
);

-- Crear la tabla Det.Pedido
CREATE TABLE Det_Pedido OF OBJ_Det_Pedido_type (
  id_detalle PRIMARY KEY
);

-- Crear la tabla Pedido
CREATE TABLE Pedido OF OBJ_Pedido_type (
  id_pedido PRIMARY KEY
);

-- Crear la tabla Orden Entrega
CREATE TABLE Orden_Entrega OF OBJ_Orden_Entrega_type (
  id_entrega PRIMARY KEY
);

-- Crear la tabla Orden Recogida
CREATE TABLE Orden_Recogida OF OBJ_Orden_Recogida_type (
  id_recogida PRIMARY KEY
);

-- Crear clave externa en Det_Pedido referenciando a Pedido
ALTER TABLE Det_Pedido ADD CONSTRAINT Det_Pedido_Pedido_fk FOREIGN KEY (id_pedido) REFERENCES Pedido(id_pedido);

-- Crear clave externa en Det_Pedido referenciando a Producto
ALTER TABLE Det_Pedido ADD CONSTRAINT Det_Pedido_Producto_fk FOREIGN KEY (id_producto) REFERENCES Producto(id_producto);

-- Crear clave externa en Pedido referenciando a Cliente
ALTER TABLE Pedido ADD CONSTRAINT Pedido_Cliente_fk FOREIGN KEY (cif) REFERENCES Cliente(cif);

-- Crear clave externa en Orden_Entrega referenciando a Pedido
ALTER TABLE Orden_Entrega ADD CONSTRAINT Orden_Entrega_Pedido_fk FOREIGN KEY (id_pedido) REFERENCES Pedido(id_pedido);

-- Crear clave externa en Orden_Recogida referenciando a Pedido
ALTER TABLE Orden_Recogida ADD CONSTRAINT Orden_Recogida_Pedido_fk FOREIGN KEY (id_pedido) REFERENCES Pedido(id_pedido);

-- Implementar los m�todos de los tipos de objeto
CREATE TYPE BODY OBJ_Cliente_type AS
  MEMBER FUNCTION obtenerNombre RETURN VARCHAR2 IS
  BEGIN
    RETURN self.nombre;
  END;
END;
/

CREATE TYPE BODY OBJ_Producto_type AS
  MEMBER FUNCTION obtenerDescripcion RETURN VARCHAR2 IS
  BEGIN
    RETURN self.descripcion;
  END;
END;
/

CREATE TYPE BODY OBJ_Det_Pedido_type AS
  MEMBER FUNCTION obtenerPedido RETURN NUMBER IS
  BEGIN
    RETURN self.id_pedido;
  END;

  MEMBER FUNCTION obtenerProducto RETURN NUMBER IS
  BEGIN
    RETURN self.id_producto;
  END;
END;
/

CREATE TYPE BODY OBJ_Pedido_type AS
  MEMBER FUNCTION obtenerCliente RETURN NUMBER IS
  BEGIN
    RETURN self.cif;
  END;
END;
/

CREATE TYPE BODY OBJ_Orden_Entrega_type AS
  MEMBER FUNCTION obtenerPedido RETURN NUMBER IS
  BEGIN
    RETURN self.id_pedido;
  END;
END;
/

CREATE TYPE BODY OBJ_Orden_Recogida_type AS
  MEMBER FUNCTION obtenerPedido RETURN NUMBER IS
  BEGIN
    RETURN self.id_pedido;
  END;
END;
/


        


-- Eliminar registros de la tabla Orden_Recogida
DELETE FROM Orden_Recogida;

-- Eliminar registros de la tabla Orden_Entrega
DELETE FROM Orden_Entrega;

-- Eliminar registros de la tabla Det_Pedido
DELETE FROM Det_Pedido;

-- Eliminar registros de la tabla Pedido
DELETE FROM Pedido;

-- Eliminar registros de la tabla Producto
DELETE FROM Producto;

-- Eliminar registros de la tabla Cliente
DELETE FROM Cliente;


-- Insertar datos en la tabla Cliente
INSERT INTO Cliente (cif, nombre, direccion, telefono, numero_cuenta)
VALUES (545874125, 'John Doe', '123 Main Street', '658974125', 987654321);

INSERT INTO Cliente (cif, nombre, direccion, telefono, numero_cuenta)
VALUES (55558963, 'Jane Smith', '456 Park Avenue', '45878741', 123456789);

INSERT INTO Cliente (cif, nombre, direccion, telefono, numero_cuenta)
VALUES (98787412, 'Michael Johnson', '789 Elm Road', '65895120', 654321987);

INSERT INTO Cliente (cif, nombre, direccion, telefono, numero_cuenta)
VALUES (12365478, 'Emily Davis', '321 Oak Lane', '658974120', 456789123);

INSERT INTO Cliente (cif, nombre, direccion, telefono, numero_cuenta)
VALUES (98778965, 'David Wilson', '987 Pine Street', '698989865', 789123456);


-- Insertar datos en la tabla Producto
INSERT INTO Producto (id_producto, nombre, descripcion, disponibilidad)
VALUES (1, 'maquillaje', 'Maquillaje usado para pintar a los actores', 'Disponible');

INSERT INTO Producto (id_producto, nombre, descripcion, disponibilidad)
VALUES (2, 'ropa', 'Vestimenta que se usara en la pelicula', 'Agotado');

INSERT INTO Producto (id_producto, nombre, descripcion, disponibilidad)
VALUES (3, 'acesorios', 'accesorios para los actores en las peliculas', 'Disponible');

INSERT INTO Producto (id_producto, nombre, descripcion, disponibilidad)
VALUES (4, 'decoracion', 'Decoracion del escenario', 'Disponible');

INSERT INTO Producto (id_producto, nombre, descripcion, disponibilidad)
VALUES (5, 'calzado', 'Calzado utilizado por los actores', 'Agotado');

-- Insertar datos en la tabla Pedido
INSERT INTO Pedido (id_pedido, fecha, estado, factura, cif)
VALUES (1, TO_DATE('2023-05-17', 'YYYY-MM-DD'), 'Pendiente', 'Factura 1', 545874125);

INSERT INTO Pedido (id_pedido, fecha, estado, factura, cif)
VALUES (2, TO_DATE('2023-06-27', 'YYYY-MM-DD'), 'Entregado', 'Factura 2', 55558963);

INSERT INTO Pedido (id_pedido, fecha, estado, factura, cif)
VALUES (3, TO_DATE('2023-05-14', 'YYYY-MM-DD'), 'Pendiente', 'Factura 3', 98787412);

INSERT INTO Pedido (id_pedido, fecha, estado, factura, cif)
VALUES (4, TO_DATE('2023-02-10', 'YYYY-MM-DD'), 'Entregado', 'Factura 4', 12365478);

INSERT INTO Pedido (id_pedido, fecha, estado, factura, cif)
VALUES (5, TO_DATE('2023-10-19', 'YYYY-MM-DD'), 'Pendiente', 'Factura 5', 98778965);


-- Insertar datos en la tabla Det.Pedido
INSERT INTO Det_Pedido (id_detalle, id_pedido, id_producto)
VALUES (1, 1, 1);

INSERT INTO Det_Pedido (id_detalle, id_pedido, id_producto)
VALUES (2, 5, 2);

INSERT INTO Det_Pedido (id_detalle, id_pedido, id_producto)
VALUES (3, 2, 1);

INSERT INTO Det_Pedido (id_detalle, id_pedido, id_producto)
VALUES (4, 4, 5);

INSERT INTO Det_Pedido (id_detalle, id_pedido, id_producto)
VALUES (5, 3, 4);



-- Insertar datos en la tabla Orden Entrega
INSERT INTO Orden_Entrega (id_entrega, fecha_entrega, id_pedido, direcion_entrega, transportista)
VALUES (1, TO_DATE('2023-05-30', 'YYYY-MM-DD'), 1, 'Direcci�n de entrega 1', 'Mario');

INSERT INTO Orden_Entrega (id_entrega, fecha_entrega, id_pedido, direcion_entrega, transportista)
VALUES (2, TO_DATE('2023-04-29', 'YYYY-MM-DD'), 4, '987 Pine Street', 'Luis');

INSERT INTO Orden_Entrega (id_entrega, fecha_entrega, id_pedido, direcion_entrega, transportista)
VALUES (3, TO_DATE('2023-02-18', 'YYYY-MM-DD'), 5, '321 Oak Lane', 'Marta');

INSERT INTO Orden_Entrega (id_entrega, fecha_entrega, id_pedido, direcion_entrega, transportista)
VALUES (4, TO_DATE('2023-08-29', 'YYYY-MM-DD'), 3, '456 Park Avenue', 'Raul');

INSERT INTO Orden_Entrega (id_entrega, fecha_entrega, id_pedido, direcion_entrega, transportista)
VALUES (5, TO_DATE('2023-10-06', 'YYYY-MM-DD'), 2, '789 Elm Road', 'Sergio');

-- Insertar datos en la tabla Orden Recogida
INSERT INTO Orden_Recogida (id_recogida, fecha_recogida, id_pedido, transportista)
VALUES (1, TO_DATE('2023-05-30', 'YYYY-MM-DD'), 2, 'Daniel');

INSERT INTO Orden_Recogida (id_recogida, fecha_recogida, id_pedido, transportista)
VALUES (2, TO_DATE('2023-01-29', 'YYYY-MM-DD'), 1, 'Marcos');

INSERT INTO Orden_Recogida (id_recogida, fecha_recogida, id_pedido, transportista)
VALUES (3, TO_DATE('2023-02-28', 'YYYY-MM-DD'), 3, 'Ramos');

INSERT INTO Orden_Recogida (id_recogida, fecha_recogida, id_pedido, transportista)
VALUES (4, TO_DATE('2023-05-27', 'YYYY-MM-DD'), 5, 'Diego');

INSERT INTO Orden_Recogida (id_recogida, fecha_recogida, id_pedido, transportista)
VALUES (5, TO_DATE('2023-09-26', 'YYYY-MM-DD'), 4, 'Fernando');

--Esta consulta muestra la cantidad de pedidos en cada estado
SELECT estado, COUNT(*) FROM Pedido GROUP BY estado;

--Esta consulta devuelve la fecha m�xima de los pedidos registrados
SELECT MAX(fecha) FROM Pedido;

--Esta consulta recupera el nombre de los clientes que tienen pedidos en estado "Entregado".
SELECT nombre FROM Cliente WHERE cif IN (SELECT cif FROM Pedido WHERE estado = 'Entregado');
--Esta consulta devuelve el nombre del producto y su estado
SELECT nombre, CASE WHEN disponibilidad = 'Disponible' THEN 'Disponible' ELSE 'No disponible' END AS estado_producto FROM Producto;

--Esta consulta muestra el nombre, tel�fono, n�mero de cuenta y saldo
SELECT nombre, telefono, numero_cuenta, numero_cuenta - 100000000 AS saldo FROM Cliente;

--Esta consulta muestra el ID del pedido y el nombre del cliente correspondiente utilizando la coincidencia del CIF en las tablas Pedido y Cliente.
SELECT Pedido.id_pedido, Cliente.nombre FROM Pedido INNER JOIN Cliente ON Pedido.cif = Cliente.cif;

--Esta consulta recupera el ID del pedido, el nombre del cliente y el nombre del producto asociado utilizando las relaciones establecidas entre las tablas Pedido, Cliente, Det_Pedido y Producto.
SELECT Pedido.id_pedido, Cliente.nombre, Producto.nombre FROM Pedido INNER JOIN Cliente ON Pedido.cif = Cliente.cif INNER JOIN Det_Pedido ON Pedido.id_pedido = Det_Pedido.id_pedido INNER JOIN Producto ON Det_Pedido.id_producto = Producto.id_producto;

--Esta consulta devuelve el ID del pedido y el nombre del cliente correspondiente solo para los pedidos con estado 'Pendiente'.
SELECT Pedido.id_pedido, Cliente.nombre FROM Pedido INNER JOIN Cliente ON Pedido.cif = Cliente.cif WHERE Pedido.estado = 'Pendiente';

--Esta consulta muestra el nombre de cada cliente y la cantidad de pedidos que han realizado, utilizando la funci�n de agregaci�n COUNT y la combinaci�n INNER JOIN.
SELECT Cliente.nombre, COUNT(*) AS num_pedidos FROM Cliente INNER JOIN Pedido ON Cliente.cif = Pedido.cif GROUP BY Cliente.nombre;

--Esta consulta recupera el nombre del cliente y la fecha del pedido correspondiente, ordenados por fecha de forma descendente.Esta consulta recupera el nombre del cliente y la fecha del pedido correspondiente, ordenados por fecha de forma descendente.
SELECT Cliente.nombre, Pedido.fecha FROM Cliente INNER JOIN Pedido ON Cliente.cif = Pedido.cif ORDER BY Pedido.fecha DESC;

--Esta consulta recupera todos los registros de la tabla Cliente ordenados alfab�ticamente por nombre de forma ascendente.
SELECT * FROM Cliente ORDER BY nombre ASC;

--Esta consulta recupera el nombre y la direcci�n de los clientes cuyo nombre contiene "Doe" o cuya direcci�n contiene "Main", utilizando INNER JOIN con la tabla Pedido.
SELECT Cliente.nombre, Cliente.direccion FROM Cliente INNER JOIN Pedido ON Cliente.cif = Pedido.cif WHERE Cliente.nombre LIKE '%Doe%' OR Cliente.direccion LIKE '%Main%';

--Esta consulta muestra el nombre del cliente y la fecha del pedido correspondiente utilizando INNER JOIN entre las tablas Cliente y Pedido.
SELECT Cliente.nombre, Pedido.fecha FROM Cliente INNER JOIN Pedido ON Cliente.cif = Pedido.cif;

--Esta consulta recupera el nombre y la direcci�n de los clientes cuyo nombre contiene "Smith" y cuya direcci�n contiene "Park", utilizando INNER JOIN con la tabla Pedido.
SELECT Cliente.nombre, Cliente.direccion FROM Cliente INNER JOIN Pedido ON Cliente.cif = Pedido.cif WHERE Cliente.nombre LIKE '%Smith%' AND Cliente.direccion LIKE '%Park%';

--Esta consulta devuelve el nombre del cliente y la fecha m�s reciente de los pedidos realizados por ese cliente, utilizando INNER JOIN y la funci�n de agregaci�n MAX.
SELECT Cliente.nombre, MAX(Pedido.fecha) AS ultima_fecha FROM Cliente INNER JOIN Pedido ON Cliente.cif = Pedido.cif GROUP BY Cliente.nombre;

--Esta consulta muestra el nombre del cliente y la fecha del pedido correspondiente para los pedidos realizados en el mes de mayo de 2023, utilizando INNER JOIN con la tabla Pedido y la cl�usula BETWEEN para la condici�n de rango.
SELECT Cliente.nombre, Pedido.fecha FROM Cliente INNER JOIN Pedido ON Cliente.cif = Pedido.cif WHERE Pedido.fecha BETWEEN TO_DATE('2023-05-01', 'YYYY-MM-DD') AND TO_DATE('2023-05-31', 'YYYY-MM-DD');

--SELECT nombre, direccion FROM Cliente WHERE numero_cuenta IS NOT NULL ORDER BY nombre ASC;
SELECT nombre, direccion FROM Cliente WHERE numero_cuenta IS NOT NULL ORDER BY nombre ASC;

--Esta consulta muestra el estado de los pedidos y la cantidad total de pedidos en cada estado. 
SELECT estado, COUNT(*) AS total_pedidos FROM Pedido GROUP BY estado;

--Esta consulta muestra el CIF de los clientes y el promedio de los n�meros de cuenta para cada cliente, pero solo muestra aquellos clientes cuyo promedio de cuenta sea mayor a 500,000,000. 
SELECT cif, AVG(numero_cuenta) AS promedio_cuenta FROM Cliente GROUP BY cif HAVING AVG(numero_cuenta) > 500000000;

--Esta consulta recupera todas las direcciones �nicas de la tabla Cliente.
SELECT DISTINCT direccion FROM Cliente;




































